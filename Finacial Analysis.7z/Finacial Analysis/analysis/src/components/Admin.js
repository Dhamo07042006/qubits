import React, { useEffect } from 'react';

const Admin = () => {
  const adminPassword = "admin123"; // Replace this with your actual admin password

  useEffect(() => {
    const password = prompt("Enter the admin password:");
    if (password !== adminPassword) {
      alert("Access denied. You are not authorized to view this page.");
      // No redirection occurs here, just an alert
    } else {
      alert("Access granted. Welcome to the admin page!");
      // Here you can add any admin content or functionalities
    }
  }, []);

  return (
    <div>
      <h1>Admin Page</h1>
      {/* Add any additional admin content here */}
    </div>
  );
};

export default Admin;
