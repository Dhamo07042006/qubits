import React from 'react';
import { motion } from 'framer-motion';
import './Navbar.css'; // Import the CSS file for custom styles

const Navbar = () => {
  return (
    <motion.nav
      className="navbar"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="navbar-content">
        <h2 className="navbar-title">Dashboard</h2>
        <div className="navbar-links">
          <motion.button
            className="navbar-button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Help
          </motion.button>
          <motion.button
            className="navbar-button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Contact
          </motion.button>
          <motion.button
            className="navbar-button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Report
          </motion.button>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;
