import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import axios from 'axios'; // Import axios for making API requests
import BackgroundImage from '../Assests/image5.jpg';

const Dashboard = () => {
  const [file1, setFile1] = useState(null);
  const [result1, setResult1] = useState(null);
  const [error1, setError1] = useState(null);

  const [file2, setFile2] = useState(null);
  const [result2, setResult2] = useState(null);
  const [error2, setError2] = useState(null);

  // Handle file changes for both sections
  const handleFileChange = (event, section) => {
    if (section === 1) {
      setFile1(event.target.files[0]);
    } else {
      setFile2(event.target.files[0]);
    }
  };

  // Handle file submission for analysis
  const handleSubmit = async (section) => {
    const file = section === 1 ? file1 : file2;

    if (file) {
      const formData = new FormData();
      formData.append('file', file); // Append the file to form data

      try {
        // Send a POST request to the FastAPI backend
        const response = await axios.post('http://127.0.0.1:5000/api/analyze', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        // Handle the results
        if (section === 1) {
          setResult1(response.data); // Set the result for the first section (Revenue Analysis)
          setError1(null); // Clear any previous errors
        } else {
          setResult2(response.data); // Set the result for the second section (Marketing Analysis)
          setError2(null);
        }
      } catch (error) {
        console.error('Error uploading file:', error);
        // Set error message for the appropriate section
        if (section === 1) {
          setError1('Failed to analyze file.');
        } else {
          setError2('Failed to analyze file.');
        }
      }
    } else {
      // Set error if no file is selected
      if (section === 1) {
        setError1('No file selected.');
      } else {
        setError2('No file selected.');
      }
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => setFile1(acceptedFiles[0]), // Modify as needed
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-700 to-gray-600 p-6">
      <div className="container mx-auto">
        {/* Centered Business Analysis Section */}
        <div className="flex justify-center mb-8">
          <motion.div
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg shadow-xl rounded-lg p-6 text-white flex items-center max-w-4xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
          >
            {/* Left side: Image */}
            <div className="w-1/2 p-4">
              <img src={BackgroundImage} alt="Business Analysis" className="w-full h-auto rounded-lg shadow-md" />
            </div>

            {/* Right side: Content */}
            <div className="w-1/2 p-4">
              <h2 className="text-2xl font-bold mb-4">Business Analysis</h2>
              <p>Analyze your business performance with real-time data.</p>
            </div>
          </motion.div>
        </div>

        {/* File Upload Sections */}
        <div className="flex justify-between max-w-4xl mx-auto">
          {/* First Upload Section */}
          <motion.div
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg shadow-xl rounded-lg p-6 text-white w-1/2 mr-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeInOut', delay: 0.3 }}
          >
            <h2 className="text-xl font-bold mb-4">Revenue Analysis</h2>

            <div className="form-group mb-4">
              <label htmlFor="fileUpload1" className="block mb-2 text-sm font-medium text-gray-300">
                Upload Data:
              </label>
              <input
                type="file"
                id="fileUpload1"
                onChange={(e) => handleFileChange(e, 1)}
                className="w-full px-4 py-2 border border-gray-600 rounded-lg bg-gray-700 text-white"
              />
            </div>

            <div
              {...getRootProps()}
              className={`w-full p-4 border-2 border-dashed rounded-lg text-center cursor-pointer transition duration-300 ease-in-out ${
                isDragActive ? 'border-purple-400' : 'border-gray-600'
              }`}
            >
              <input {...getInputProps()} />
              {isDragActive ? (
                <p className="text-purple-400">Drop the file here...</p>
              ) : (
                <p className="text-gray-300">Drag and drop a file here, or click to select a file</p>
              )}
            </div>

            {file1 && (
              <div className="mt-4 text-gray-300">
                <strong>Selected file:</strong> {file1.name}
              </div>
            )}

            <button
              onClick={() => handleSubmit(1)}
              className="mt-4 w-full py-2 px-4 bg-purple-700 text-white rounded-lg font-medium hover:bg-purple-600 transition duration-300 ease-in-out"
            >
              Analyze File
            </button>

            {result1 && (
              <div className="mt-6">
                <h3 className="text-xl font-bold text-center text-white">Analysis Results</h3>
                <pre className="bg-gray-700 p-4 rounded-lg text-white">{JSON.stringify(result1, null, 2)}</pre>
              </div>
            )}
            {error1 && (
              <div className="mt-6 text-red-400 text-center">
                {error1}
              </div>
            )}
          </motion.div>

          {/* Second Upload Section */}
          <motion.div
            className="bg-gray-800 bg-opacity-50 backdrop-blur-lg shadow-xl rounded-lg p-6 text-white w-1/2 ml-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeInOut', delay: 0.3 }}
          >
            <h2 className="text-xl font-bold mb-4">Marketing Analysis</h2>

            <div className="form-group mb-4">
              <label htmlFor="fileUpload2" className="block mb-2 text-sm font-medium text-gray-300">
                Upload Data:
              </label>
              <input
                type="file"
                id="fileUpload2"
                onChange={(e) => handleFileChange(e, 2)}
                className="w-full px-4 py-2 border border-gray-600 rounded-lg bg-gray-700 text-white"
              />
            </div>

            <div
              {...getRootProps()}
              className={`w-full p-4 border-2 border-dashed rounded-lg text-center cursor-pointer transition duration-300 ease-in-out ${
                isDragActive ? 'border-purple-400' : 'border-gray-600'
              }`}
            >
              <input {...getInputProps()} />
              {isDragActive ? (
                <p className="text-purple-400">Drop the file here...</p>
              ) : (
                <p className="text-gray-300">Drag and drop a file here, or click to select a file</p>
              )}
            </div>

            {file2 && (
              <div className="mt-4 text-gray-300">
                <strong>Selected file:</strong> {file2.name}
              </div>
            )}

            <button
              onClick={() => handleSubmit(2)}
              className="mt-4 w-full py-2 px-4 bg-purple-700 text-white rounded-lg font-medium hover:bg-purple-600 transition duration-300 ease-in-out"
            >
              Analyze File
            </button>

            {result2 && (
              <div className="mt-6">
                <h3 className="text-xl font-bold text-center text-white">Analysis Results</h3>
                <pre className="bg-gray-700 p-4 rounded-lg text-white">{JSON.stringify(result2, null, 2)}</pre>
              </div>
            )}
            {error2 && (
              <div className="mt-6 text-red-400 text-center">
                {error2}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
