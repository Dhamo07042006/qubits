import React from 'react';
import { motion } from 'framer-motion';

const Upload = () => {
  const handleFileChange = (event) => {
    const files = event.target.files;
    if (files.length > 0) {
      alert(`Selected file: ${files[0].name}`);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <motion.div
        className="p-10 bg-white rounded-lg shadow-lg text-center"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-4">Upload File</h1>
        <p className="mb-6">Click the button below to upload a file.</p>
        <label htmlFor="file-upload" className="cursor-pointer">
          <motion.button
            className="py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300 ease-in-out"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Upload
          </motion.button>
        </label>
        <input
          id="file-upload"
          type="file"
          className="hidden"
          onChange={handleFileChange}
        />
      </motion.div>
    </div>
  );
};

export default Upload;
