// src/components/FileUpload.js

import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';

function FileUpload() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);

  // Handles file changes from both the input and drag & drop
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);

    if (selectedFile && selectedFile.type.startsWith('image/')) {
      setPreview(URL.createObjectURL(selectedFile));
    } else {
      setPreview(null);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      const selectedFile = acceptedFiles[0];
      setFile(selectedFile);

      if (selectedFile && selectedFile.type.startsWith('image/')) {
        setPreview(URL.createObjectURL(selectedFile));
      } else {
        setPreview(null);
      }
    },
  });

  return (
    <div className="flex flex-col items-center justify-center py-12">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="p-8 bg-white shadow-lg rounded-lg w-full max-w-lg"
      >
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
          Data Upload
        </h2>

        {/* File Upload (traditional input) */}
        <div className="form-group mb-4">
          <label
            htmlFor="fileUpload"
            className="block mb-2 text-sm font-medium text-gray-700"
          >
            Upload File:
          </label>
          <input
            type="file"
            id="fileUpload"
            onChange={handleFileChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
          />
        </div>

        {/* Drag and Drop Area */}
        <div
          {...getRootProps()}
          className={`w-full p-4 border-2 border-dashed rounded-lg text-center cursor-pointer transition duration-300 ease-in-out ${
            isDragActive ? 'border-purple-500' : 'border-gray-300'
          }`}
        >
          <input {...getInputProps()} />
          {isDragActive ? (
            <p className="text-purple-500">Drop the file here...</p>
          ) : (
            <p className="text-gray-700">
              Drag and drop a file here, or click to select a file
            </p>
          )}
        </div>

        {/* Show file details */}
        {file && (
          <div className="mt-4">
            {preview ? (
              <a href={preview} download={file.name}>
                <img src={preview} alt="preview" className="max-w-full" />
              </a>
            ) : (
              <div>
                <strong>Selected file:</strong> {file.name}
                <br />
                <a href={URL.createObjectURL(file)} download={file.name}>
                  Click here to download
                </a>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default FileUpload;
