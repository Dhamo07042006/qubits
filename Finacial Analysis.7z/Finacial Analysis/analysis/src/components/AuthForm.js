import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FaFacebook, FaTwitter, FaGoogle } from 'react-icons/fa';
import backgroundImage from '../Assests/image8.jpg'; // Ensure this path is correct

function AuthForm() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [registeredEmail, setRegisteredEmail] = useState('');
  const [registeredPassword, setRegisteredPassword] = useState('');

  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    if (isLogin) {
      if (email === registeredEmail && password === registeredPassword) {
        console.log('Login successful! Redirecting to dashboard...');
        navigate('/dashboard'); // Redirect to the dashboard
      } else {
        alert('Login failed. Please check your credentials.');
      }
    } else {
      if (name && email && password) {
        console.log('Sign-up successful!');
        alert('Sign-up successful. You can now log in.');

        setRegisteredEmail(email);
        setRegisteredPassword(password);
        setIsLogin(true);
      } else {
        alert('Sign-up failed. Please fill in all fields.');
      }
    }
  };

  const handleSocialLogin = (platform) => {
    alert(`Login with ${platform} is not yet implemented.`);
  };

  return (
    <div
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage: `url(${backgroundImage})`, // Set the background image
        backgroundSize: 'cover', // Cover the entire div
        backgroundPosition: 'center', // Center the image
        backgroundRepeat: 'no-repeat', // Prevent repeating the image
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative p-8 rounded-lg shadow-lg w-full max-w-md backdrop-blur-lg bg-white bg-opacity-20"
        style={{
          backdropFilter: 'blur(2px)',
          backgroundColor: 'rgba(255, 255, 255, 0.6)',
        }}
      >
        <div className="flex justify-center mb-6">
          <button
            onClick={() => setIsLogin(true)}
            className={`mr-2 py-2 px-4 rounded-lg font-medium text-white transition duration-300 ease-in-out ${
              isLogin ? 'bg-black' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`py-2 px-4 rounded-lg font-medium text-white transition duration-300 ease-in-out ${
              !isLogin ? 'bg-black' : 'bg-gray-300 hover:bg-gray-400'
            }`}
          >
            Sign Up
          </button>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={isLogin ? 'login' : 'signup'}
            initial="initial"
            animate="animate"
            exit="exit"
            variants={{
              initial: { opacity: 0 },
              animate: { opacity: 1 },
              exit: { opacity: 0 },
            }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">
              {isLogin ? 'Login' : 'Sign Up'}
            </h1>
            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <div className="form-group">
                  <label
                    htmlFor="name"
                    className="block mb-2 text-sm font-medium text-gray-700"
                  >
                    Name:
                  </label>
                  <motion.input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 focus:ring-purple-500 focus:ring-1 transition duration-300 ease-in-out"
                  />
                </div>
              )}
              <div className="form-group">
                <label
                  htmlFor="email"
                  className="block mb-2 text-sm font-medium text-gray-700"
                >
                  Email:
                </label>
                <motion.input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 focus:ring-purple-500 focus:ring-1 transition duration-300 ease-in-out"
                />
              </div>
              <div className="form-group">
                <label
                  htmlFor="password"
                  className="block mb-2 text-sm font-medium text-gray-700"
                >
                  Password:
                </label>
                <motion.input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 focus:ring-purple-500 focus:ring-1 transition duration-300 ease-in-out"
                />
              </div>
              <motion.button
                type="submit"
                className="w-full py-2 px-4 bg-black text-white rounded-lg font-medium hover:bg-gray-500 transition duration-300 ease-in-out"
              >
                {isLogin ? 'Login' : 'Sign Up'}
              </motion.button>
            </form>

            <div className="flex justify-center mt-6 space-x-4">
              <motion.div
                onClick={() => handleSocialLogin('Facebook')}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-full bg-gray-100 cursor-pointer"
              >
                <FaFacebook className="text-blue-600" size={24} />
              </motion.div>
              <motion.div
                onClick={() => handleSocialLogin('Twitter')}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-full bg-gray-100 cursor-pointer"
              >
                <FaTwitter className="text-blue-400" size={24} />
              </motion.div>
              <motion.div
                onClick={() => handleSocialLogin('Google')}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-full bg-gray-100 cursor-pointer"
              >
                <FaGoogle className="text-red-500" size={24} />
              </motion.div>
            </div>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

export default AuthForm;
