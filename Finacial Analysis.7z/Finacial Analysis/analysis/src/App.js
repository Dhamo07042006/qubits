import React from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import AuthForm from './components/AuthForm';
import Dashboard from './components/Dashboard';
import Navbar from './components/Navbar';

function App() {
  const location = useLocation();

  // Check if the current path is the login or signup page
  const isAuthPage = location.pathname === '/' || location.pathname === '/signup';

  return (
    <>
      {!isAuthPage && <Navbar />} {/* Render Navbar only if not on auth pages */}
      <Routes>
        <Route path="/" element={<AuthForm />} />
        <Route path="/dashboard" element={<Dashboard />} />
        {/* Add more routes as needed */}
      </Routes>
    </>
  );
}

// Wrap App component with Router
function AppWrapper() {
  return (
    <Router>
      <App />
    </Router>
  );
}

export default AppWrapper;
